Presentation Studio editable project

Unzip the complete package and open index.html. No server or database is required. Keep assets beside index.html.

Open Editor or press J to edit content, tables, questions, commands, branding, and loops. Edit Media or E opens the Media Manager. Import this editable ZIP before re-exporting so all media bytes, including checkpoint and Trash assets, are available. Undo/redo history and recovery snapshots are included.

Browser drafts are recovery aids on the same browser/computer, not backups. Export an editable ZIP for a durable portable copy. Exporting does not clear undo history or reset the presentation.

OBS: Browser Source, Local File, index.html, 1920 x 1080. Actual OBS testing is performed on your OBS installation.

Use New presentation for a blank project or the built-in demo. Import an editable ZIP to open another presentation.
