Presentation Studio playback export

Unzip the complete package and open index.html. No server or database is required. Keep assets beside index.html.

Editor controls, recovery history, Trash, and custom presenter notes are omitted from this export. HTML and included content remain inspectable; this is not access control or copy protection. Keep the editable project separately.

Browser drafts are recovery aids on the same browser/computer, not backups. Export an editable ZIP for a durable portable copy. Exporting does not clear undo history or reset the presentation.

OBS: Browser Source, Local File, index.html, 1920 x 1080. Actual OBS testing is performed on your OBS installation.

Use New presentation for a blank project or the built-in demo. Import an editable ZIP to open another presentation.
